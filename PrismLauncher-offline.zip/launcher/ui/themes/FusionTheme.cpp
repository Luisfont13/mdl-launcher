#include "FusionTheme.h"

QString FusionTheme::qtTheme()
{
    return "Fusion";
}
